package StuffLendingSystem.Model;

import java.time.LocalDate;
import java.util.UUID;

public class Contract {
    private final  String contractID;
    private final  Member borrower;
    private final Item item;
    private final  LocalDate startDate;
    private final  LocalDate endDate;
    private final  int creditsTransferred;

    public Contract(Member borrower, Item item, LocalDate startDate, LocalDate endDate) {
        this.contractID = UUID.randomUUID().toString().substring(0, 6);
        this.borrower = borrower;
        this.item = item;
        this.startDate = startDate;
        this.endDate = endDate;
        this.creditsTransferred = item.getCostPerDay() * calculateDuration(); // Calculate credits based on duration
    }

    private int calculateDuration() {
        return (int) (endDate.toEpochDay() - startDate.toEpochDay());
    }

    // Getter methods for borrower and item
    public Member getBorrower() {
        return borrower;
    }

    public Item getItem() {
        return item;
    }

    // Getter methods for startDate and endDate
    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void viewContractDetails() {
        System.out.println("Contract ID: " + contractID);
        System.out.println("Borrower: " + borrower.getName());
        System.out.println("Item: " + item.getName());
        System.out.println("Start Date: " + startDate);
        System.out.println("End Date: " + endDate);
        System.out.println("Credits Transferred: " + creditsTransferred);
    }

    public boolean validateContract() {
        if (borrower.getCredits() >= creditsTransferred) {
            borrower.deductCredits(creditsTransferred);  // Deduct credits from borrower
            item.getOwner().addCredits(creditsTransferred);  // Transfer credits to owner
            return true;
        }
        return false;
    }
}
