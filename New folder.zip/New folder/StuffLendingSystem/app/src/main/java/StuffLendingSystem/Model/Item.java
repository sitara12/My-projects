package StuffLendingSystem.Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Item {
    private String itemID;
    private String name;
    private String description;
    private String category;
    private Member owner;
    private int costPerDay;
    private LocalDate createdDate;
    private List<Contract> contracts;

    public Item(String name, String description, String category, Member owner, int costPerDay) {
        this.itemID = UUID.randomUUID().toString().substring(0, 6);
        this.name = name;
        this.description = description;
        this.category = category;
        this.owner = owner;
        this.costPerDay = costPerDay;
        this.createdDate = LocalDate.now();
        this.contracts = new ArrayList<>();
    }

    // Getters
    public String getName() { return name; }
    public Member getOwner() { return owner; }
    public int getCostPerDay() { return costPerDay; }
    public String getCategory() { return category; } // Add this getter
    public List<Contract> getContracts() { return contracts; }

    public void viewItemDetails() {
        System.out.println("Item Name: " + name);
        System.out.println("Description: " + description);
        System.out.println("Category: " + category);
        System.out.println("Cost per Day: " + costPerDay + " credits");
        System.out.println("Owner: " + owner.getName());
        System.out.println("Contracts: " + contracts.size());
    }

    public void addContract(Contract contract) {
        this.contracts.add(contract);
    }
}
