package StuffLendingSystem.View;

import java.util.List;
import java.util.Scanner;
import StuffLendingSystem.Model.Member;

public class View {
    private Scanner scanner;

    public View(Scanner scanner) {
        this.scanner = scanner;
    }

    public void displayMenu() {
        System.out.println("1. Add Member");
        System.out.println("2. Add Item");
        System.out.println("3. Create Lending Contract");
        System.out.println("4. View Member Info");
        System.out.println("5. Advance Time");
        System.out.println("6. Exit");
    }

    public int readUserInput() {
        while (true) {
            try {
                System.out.print("Choose an option: ");
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }
    }

    public void displayMemberList(List<Member> members) {
        if (members.isEmpty()) {
            System.out.println("No members available.");
            return;
        }
        for (Member member : members) {
            member.viewMemberDetails();
        }
    }
}
