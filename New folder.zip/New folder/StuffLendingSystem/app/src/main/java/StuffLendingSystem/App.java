package StuffLendingSystem;

import java.time.LocalDate;
import java.util.Scanner;
import StuffLendingSystem.Controller.LendingSystem;
import StuffLendingSystem.View.View;
public class App {
    public static void main(String[] args) {
        LendingSystem lendingSystem = new LendingSystem();
        Scanner scanner = new Scanner(System.in);
        View view = new View(scanner);

        while (true) {
            view.displayMenu();
            int choice = view.readUserInput();

            switch (choice) {
                case 1:
                    System.out.print("Enter member name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter member email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter member phone number: ");
                    String phoneNumber = scanner.nextLine();
                    lendingSystem.addMember(name, email, phoneNumber);
                    System.out.println("Member added successfully!");
                    break;
                case 2:
                    System.out.print("Enter member name for the item: ");
                    String memberName = scanner.nextLine();
                    System.out.print("Enter item name: ");
                    String itemName = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter item category: ");
                    String category = scanner.nextLine();
                    System.out.print("Enter cost per day: ");
                    int costPerDay = Integer.parseInt(scanner.nextLine());
                    lendingSystem.addItem(memberName, itemName, description, category, costPerDay);
                    System.out.println("Item added successfully!");
                    break;
                case 3:
                    System.out.print("Enter borrower name: ");
                    String borrowerName = scanner.nextLine();
                    System.out.print("Enter item name: ");
                    String itemNameForContract = scanner.nextLine();
                    System.out.print("Enter contract start date (yyyy-mm-dd): ");
                    LocalDate startDate = LocalDate.parse(scanner.nextLine());
                    System.out.print("Enter contract end date (yyyy-mm-dd): ");
                    LocalDate endDate = LocalDate.parse(scanner.nextLine());
                    lendingSystem.createLendingContract(borrowerName, itemNameForContract, startDate, endDate);
                    break;
                case 4:
                    System.out.print("Enter member name to view info: ");
                    String memberToView = scanner.nextLine();
                    lendingSystem.viewMemberInfo(memberToView);
                    break;
                case 5:
                    lendingSystem.advanceTime();
                    break;
                case 6:
                    System.out.println("Exiting the system...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }
}
