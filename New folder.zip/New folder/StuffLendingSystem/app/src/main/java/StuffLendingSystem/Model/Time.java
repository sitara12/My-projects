package StuffLendingSystem.Model;

public class Time {
    private int currentDay;

    public Time() {
        this.currentDay = 0; // Start at day 0
    }

    public void advanceDay() {
        currentDay++;
    }

    public int getCurrentDay() {
        return currentDay;
    }

    public void setCurrentDay(int day) {
        this.currentDay = day;
    }
}
