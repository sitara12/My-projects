package StuffLendingSystem.Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import StuffLendingSystem.Model.Contract;
import StuffLendingSystem.Model.Item;
import StuffLendingSystem.Model.Member;
import StuffLendingSystem.Model.Time;

public class LendingSystem {
    private final List<Member> members;
    private final List<Item> items;
    private final List<Contract> contracts;
    private final Time time;

    public LendingSystem() {
        this.members = new ArrayList<>();
        this.items = new ArrayList<>();
        this.contracts = new ArrayList<>();
        this.time = new Time();
    }

    // Getter methods for testing purposes

    public List<Member> getMembers() {
        return members;
    }

    public List<Item> getItems() {
        return items;
    }

    public List<Contract> getContracts() {
        return contracts;
    }

    public void addMember(String name, String email, String phoneNumber) {
        Member member = new Member(name, email, phoneNumber);
        members.add(member);
    }

    public void addItem(String memberName, String itemName, String description, String category, int costPerDay) {
        Member member = findMember(memberName);
        if (member != null) {
            Item item = new Item(itemName, description, category, member, costPerDay);
            member.addItem(item);
            items.add(item);
        } else {
            System.out.println("Member not found!");
        }
    }

    public void createLendingContract(String borrowerName, String itemName, LocalDate startDate, LocalDate endDate) {
        Member borrower = findMember(borrowerName);
        Item item = findItem(itemName);

        if (borrower != null && item != null && isItemAvailable(item, startDate, endDate)) {
            Contract contract = new Contract(borrower, item, startDate, endDate);
            if (contract.validateContract()) {
                contracts.add(contract);
                item.addContract(contract);
                System.out.println("Contract created successfully!");
            } else {
                System.out.println("Not enough credits for the borrower.");
            }
        } else {
            System.out.println("Borrower or Item not found, or item is not available for the selected dates.");
        }
    }

    public void viewMemberInfo(String memberName) {
        Member member = findMember(memberName);
        if (member != null) {
            member.viewMemberDetails();
        } else {
            System.out.println("Member not found.");
        }
    }

    public void advanceTime() {
        time.advanceDay();
        System.out.println("Current day: " + time.getCurrentDay());
    }

    private Member findMember(String name) {
        for (Member member : members) {
            if (member.getName().equals(name)) {
                return member;
            }
        }
        return null; // Not found
    }

    private Item findItem(String name) {
        for (Item item : items) {
            if (item.getName().equals(name)) {
                return item;
            }
        }
        return null; // Not found
    }

    private boolean isItemAvailable(Item item, LocalDate startDate, LocalDate endDate) {
        for (Contract contract : item.getContracts()) {
            if (!(endDate.isBefore(contract.getStartDate()) || startDate.isAfter(contract.getEndDate()))) {
                return false; // Conflict found
            }
        }
        return true; // Item is available
    }
}
