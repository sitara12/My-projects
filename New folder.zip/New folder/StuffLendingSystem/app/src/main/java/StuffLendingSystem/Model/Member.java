package StuffLendingSystem.Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Member {
    private String memberID;
    private String name;
    private String email;
    private String phoneNumber;
    private int credits;
    private List<Item> ownedItems;
    private LocalDate createdDate;

    public Member(String name, String email, String phoneNumber) {
        this.memberID = generateUniqueID();
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.credits = 100; // Initial credits when member is created
        this.ownedItems = new ArrayList<>();
        this.createdDate = LocalDate.now();
    }

    private String generateUniqueID() {
        return UUID.randomUUID().toString().substring(0, 6);
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhoneNumber() { return phoneNumber; }
    public int getCredits() { return credits; }
    public List<Item> getOwnedItems() { return ownedItems; }
    public LocalDate getCreatedDate() { return createdDate; }

    public void updateMemberInfo(String name, String email, String phoneNumber) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public void addItem(Item item) {
        this.ownedItems.add(item);
        this.credits += 100; // Member earns 100 credits for adding an item
    }

    public void deductCredits(int amount) {
        if (this.credits >= amount) {
            this.credits -= amount;
        } else {
            throw new IllegalArgumentException("Not enough credits.");
        }
    }

    public void addCredits(int amount) {
        this.credits += amount;
    }

    public void viewMemberDetails() {
        System.out.println("Member ID: " + memberID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Credits: " + credits);
        System.out.println("Owned Items: " + ownedItems.size());
        for (Item item : ownedItems) {
            System.out.println("- " + item.getName());
        }
    }
}
