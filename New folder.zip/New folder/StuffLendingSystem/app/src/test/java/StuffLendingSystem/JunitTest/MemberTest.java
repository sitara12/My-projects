package StuffLendingSystem.JunitTest;

import org.junit.jupiter.api.Test;

import StuffLendingSystem.Model.Item;
import StuffLendingSystem.Model.Member;

import static org.junit.jupiter.api.Assertions.*;

class MemberTest {

    @Test
    void testMemberCreation() {
        Member member = new Member("John Doe", "john@example.com", "1234567890");
        assertEquals("John Doe", member.getName());
        assertEquals("john@example.com", member.getEmail());
        assertEquals("1234567890", member.getPhoneNumber());
        assertEquals(100, member.getCredits()); // Initial credits should be 100
    }

    @Test
    void testUpdateMemberInfo() {
        Member member = new Member("Jane Doe", "jane@example.com", "0987654321");
        member.updateMemberInfo("Jane Smith", "jane.smith@example.com", "1112223333");
        assertEquals("Jane Smith", member.getName());
        assertEquals("jane.smith@example.com", member.getEmail());
        assertEquals("1112223333", member.getPhoneNumber());
    }

    @Test
    void testAddItem() {
        Member member = new Member("Alice", "alice@example.com", "9876543210");
        Item item = new Item("Book", "A fascinating book", "Literature", member, 10);
        member.addItem(item);
        assertEquals(1, member.getOwnedItems().size());
        assertEquals(item, member.getOwnedItems().get(0));
        assertEquals(200, member.getCredits()); // Credits should increase by 100
    }

    @Test
    void testDeductCredits() {
        Member member = new Member("Bob", "bob@example.com", "1231231234");
        member.deductCredits(50);
        assertEquals(50, member.getCredits()); // Should be 100 - 50 = 50
    }

    @Test
    void testDeductCreditsInsufficient() {
        Member member = new Member("Charlie", "charlie@example.com", "4564564567");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            member.deductCredits(150); // Not enough credits
        });
        assertEquals("Not enough credits.", exception.getMessage());
    }
}
