package StuffLendingSystem.JunitTest;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;


import StuffLendingSystem.Controller.LendingSystem;

class LendingSystemTest {

    @Test
    void testAddMember() {
        LendingSystem lendingSystem = new LendingSystem();
        lendingSystem.addMember("Mia", "mia@example.com", "8888888888");
        assertEquals(1, lendingSystem.getMembers().size()); // Now this should work
    }

    @Test
    void testAddItem() {
        LendingSystem lendingSystem = new LendingSystem();
        lendingSystem.addMember("Nina", "nina@example.com", "9999999999");
        lendingSystem.addItem("Nina", "Tablet", "A new tablet", "Electronics", 30);
        assertEquals(1, lendingSystem.getItems().size()); // Now this should work
    }

    @Test
    void testCreateLendingContract() {
        LendingSystem lendingSystem = new LendingSystem();
        lendingSystem.addMember("Oscar", "oscar@example.com", "1111111111");
        lendingSystem.addItem("Oscar", "Phone", "Latest smartphone", "Electronics", 40);

        lendingSystem.createLendingContract("Oscar", "Phone", LocalDate.now(), LocalDate.now().plusDays(3));
        assertEquals(1, lendingSystem.getContracts().size()); // Now this should work
    }

    @Test
    void testAdvanceTime() {
        LendingSystem lendingSystem = new LendingSystem();
        lendingSystem.advanceTime(); // You can check the output manually or add a method to check the current day
    }
}
