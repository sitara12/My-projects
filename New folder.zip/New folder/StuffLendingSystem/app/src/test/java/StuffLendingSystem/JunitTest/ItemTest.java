package StuffLendingSystem.JunitTest;

import org.junit.jupiter.api.Test;

import StuffLendingSystem.Model.Contract;
import StuffLendingSystem.Model.Item;
import StuffLendingSystem.Model.Member;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

class ItemTest {

    @Test
    void testItemCreation() {
        Member owner = new Member("Owner", "owner@example.com", "3213213210");
        Item item = new Item("Laptop", "A gaming laptop", "Electronics", owner, 20);
        assertEquals("Laptop", item.getName());
        assertEquals("Electronics", item.getCategory());
        assertEquals(20, item.getCostPerDay());
        assertEquals(owner, item.getOwner());
    }

    @Test
    void testAddContract() {
        Member owner = new Member("Owner", "owner@example.com", "6546546543");
        Item item = new Item("Camera", "A DSLR camera", "Photography", owner, 15);
        Contract contract = new Contract(owner, item, LocalDate.now(), LocalDate.now().plusDays(5));
        item.addContract(contract);
        assertEquals(1, item.getContracts().size());
        assertEquals(contract, item.getContracts().get(0));
    }

    @Test
    void testViewItemDetails() {
        Member owner = new Member("Owner", "owner@example.com", "7897897890");
        Item item = new Item("Bicycle", "A mountain bike", "Sports", owner, 5);
        item.viewItemDetails(); // This will print details; you can manually verify
    }
}
